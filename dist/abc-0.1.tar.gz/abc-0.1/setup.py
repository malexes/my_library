from setuptools import setup

setup(
    name="abc",
    version='0.1',
    description='this is library',
    url='',
    author='i am author',
    author_email='my email is private info',
    license='unlicense',
    packages=['my_lib'],
    zip_safe=False
)